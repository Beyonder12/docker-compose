CREATE USER aowfkeycloak WITH PASSWORD 'P@ssword@wf' CREATEDB;
CREATE DATABASE keycloak
    WITH 
    OWNER = aowfkeycloak
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.utf8'
    LC_CTYPE = 'en_US.utf8'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;